<?php
require("includes/common.php");

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you have a valid database connection $con
    $order_id = mysqli_real_escape_string($con, $_POST['order_id']);

    // Update the status of the order to indicate cancellation
    $query = "UPDATE user_item SET status = 3 WHERE id = $order_id";
    mysqli_query($con, $query) or die(mysqli_error($con));

    // Provide confirmation or error message
    if (mysqli_affected_rows($con) > 0) {
        $confirmation_message = "Order cancellation successful!";
    } else {
        $error_message = "Error: Unable to cancel the order. Please check your information.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancel Order | Your E-Commerce Store</title>
    <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>

        <h2>Cancel Order</h2>

        <?php
        if (isset($confirmation_message)) {
            echo "<p class='success'>$confirmation_message</p>";
        } elseif (isset($error_message)) {
            echo "<p class='error'>$error_message</p>";
        }
        ?>

        <!-- Create a simple form for order cancellation -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="order_id">Order ID:</label>
            <input type="text" name="order_id" required>
            <button type="submit">Cancel Order</button>
        </form>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>
